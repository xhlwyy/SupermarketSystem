﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace money
{
    public partial class shopt : Form
    {
        public shopt()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection mycon = new SqlConnection("Data Source=sql.dingjingjing.info;Database=lg;User ID=djj;PWD=sql6871592");
                mycon.Open();
                string s = textBox1.Text;
                Class1 get=new Class1();
                string ss = get.getsa();



                SqlCommand sqlcom = new SqlCommand("delete from shop WHERE sno='" + s + "'and cno='"+ss+"'", mycon);
                sqlcom.ExecuteNonQuery();
                sqlcom.Dispose();
                MessageBox.Show("商品删除成功");
                this.Close();
                mycon.Close();
            }
            catch { MessageBox.Show("该商品不存在，请从新输入"); }
        }
    }
}
