﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace money
{
    public partial class shopj : Form
    {
        public shopj()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Class1 get = new Class1();
            string aa = get.getsa();
            SqlConnection mycon = new SqlConnection("Data Source=sql.dingjingjing.info;Database=lg;User ID=djj;PWD=sql6871592");
            mycon.Open();

            SqlCommand sqlcom = new SqlCommand("insert into shop(sno,cno,smon,sshe,sber) values('" + textBox2.Text + "','" + aa + "','"  + textBox4.Text + "','" + textBox3.Text + "','" + textBox6.Text + "')", mycon);
            sqlcom.ExecuteNonQuery();

            sqlcom.Dispose();
            MessageBox.Show("商品添加成功！");
            mycon.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
