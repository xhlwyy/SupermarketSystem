﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace money
{
    
    public partial class sell : Form
    {
        float sd = 0;
        
        public sell()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void sell_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Class1 c = new Class1();
            string ss = c.getsa();
            SqlConnection mycon = new SqlConnection("Data Source=sql.dingjingjing.info;Database=lg;User ID=djj;PWD=sql6871592");
            mycon.Open();
            SqlDataAdapter adapter = new SqlDataAdapter("select smon from shop where sno='" + textBox1.Text + "'and cno='"+ss+"'", mycon);

            // 创建DataSet，用于存储数据.
            DataSet testDataSet = new DataSet();

            // 执行查询，并将数据导入DataSet.
            adapter.Fill(testDataSet);


            DataTable tbl = testDataSet.Tables[0];

            DataRow row = tbl.Rows[0];
           float sss= float.Parse(row[0].ToString());

           sd = sd + sss * int.Parse(textBox2.Text);



        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("总消费为" + sd.ToString());
            sd = 0;
        }
    }
}
