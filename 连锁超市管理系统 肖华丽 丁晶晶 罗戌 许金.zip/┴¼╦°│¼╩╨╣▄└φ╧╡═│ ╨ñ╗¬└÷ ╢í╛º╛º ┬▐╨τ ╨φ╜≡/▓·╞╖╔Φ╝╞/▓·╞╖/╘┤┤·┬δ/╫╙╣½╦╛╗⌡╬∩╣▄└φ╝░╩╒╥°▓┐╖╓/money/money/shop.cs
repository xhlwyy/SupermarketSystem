﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace money
{
    public partial class shop : Form
    {
        public shop()
        {
            InitializeComponent();
        }

        private void 添加商品ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            shopj shopj1 = new shopj();
            shopj1.Show();

        }

        private void 删除商品ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            shopt shopt1 = new shopt();
            shopt1.Show();
        }

        private void 商品信息更改ToolStripMenuItem_Click(object sender, EventArgs e)
        {
          
        }
    }
}
