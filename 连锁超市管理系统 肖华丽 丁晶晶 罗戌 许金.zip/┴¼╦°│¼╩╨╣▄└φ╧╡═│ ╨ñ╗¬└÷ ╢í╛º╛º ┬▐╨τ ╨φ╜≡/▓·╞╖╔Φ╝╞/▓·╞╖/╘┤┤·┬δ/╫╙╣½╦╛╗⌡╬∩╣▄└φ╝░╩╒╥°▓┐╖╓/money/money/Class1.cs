﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace money
{
    class Class1
    {
        static public String sa;
        public string getsa()
        {
            return sa;
        }
        public void setsa(string ss)
        {
            sa = ss;
        }

    }
}
