﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace lanhui
{
    public partial class Form1 : Form
    {
         string aa = "sql.dingjingjing.info";  
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
           try{   SqlConnection mycon = new SqlConnection("Data Source=" + aa + ";Database=lg;User ID=djj;PWD=sql6871592");
                mycon.Open();
                SqlDataAdapter adapter = new SqlDataAdapter("select apwd from admin where aname='" + textBox2.Text + "'", mycon);

                // 创建DataSet，用于存储数据.
                DataSet testDataSet = new DataSet();

                // 执行查询，并将数据导入DataSet.
                adapter.Fill(testDataSet);


                DataTable tbl = testDataSet.Tables[0];

                DataRow row = tbl.Rows[0];
                if (row[0].ToString() == textBox1.Text)
                {
                    zhu zhu1 = new zhu();

                    zhu1.Show();
                    this.Hide();

                }
                else
                    MessageBox.Show("密码错误请重新输入");
                mycon.Close();
            }
            catch { MessageBox.Show(",用户名不存在或网络连接失败"); }




        }

       

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection mycon = new SqlConnection("Data Source=" + aa + ";Database=lh;User ID=djj;PWD=lanhui123");
            mycon.Open();
            SqlDataAdapter adapter = new SqlDataAdapter("select shou,zhi from t3 " , mycon);

            // 创建DataSet，用于存储数据.
            DataSet testDataSet = new DataSet();

            // 执行查询，并将数据导入DataSet.
            adapter.Fill(testDataSet);


            DataTable tbl = testDataSet.Tables[0];
            DataRow row = tbl.Rows[0];
            MessageBox.Show("该系统总收入为" + row[0].ToString() + " 该系统总支出为" + row[1].ToString());
           
        }
    }
}
