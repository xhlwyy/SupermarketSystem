﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace lanhui
{
    public partial class shou : Form
    {
        public shou()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label2.Text = DateTime.Now.ToString();
        }

        private void shou_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                SqlConnection mycon = new SqlConnection("Data Source=sql.dingjingjing.info;Database=lg;User ID=djj;PWD=sql6871592");
                mycon.Open();
                SqlDataAdapter adapter = new SqlDataAdapter("select uname,umon from [user] where uno='" + textBox1.Text + "'", mycon);

                // 创建DataSet，用于存储数据.
                DataSet testDataSet = new DataSet();

                // 执行查询，并将数据导入DataSet.
                adapter.Fill(testDataSet);


                DataTable tbl = testDataSet.Tables[0];

                DataRow row = tbl.Rows[0];
                label10.Text = row[0].ToString();
                label11.Text = row[1].ToString();
                mycon.Close();
            }
            catch { }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            float a = float.Parse(textBox3.Text) *float.Parse(textBox2.Text) / 100;
            SqlConnection mycon = new SqlConnection("Data Source=sql.dingjingjing.info;Database=lg;User ID=djj;PWD=sql6871592");
            mycon.Open();
            SqlDataAdapter adapter1 = new SqlDataAdapter("select uname,umon from [user] where uno='" + textBox1.Text + "'", mycon);

            // 创建DataSet，用于存储数据.
            DataSet testDataSet1 = new DataSet();

            // 执行查询，并将数据导入DataSet.
            adapter1.Fill(testDataSet1);


            DataTable tbl1 = testDataSet1.Tables[0];

            DataRow row1 = tbl1.Rows[0];
            if (a <= float.Parse(row1[1].ToString()))
            {
                SqlCommand sqlcom = new SqlCommand("update [user] set umon=umon-" + a.ToString() + " where uno='" + textBox1.Text + "';" + ";update [user] set usco=usco+" + a.ToString() + " where uno='" + textBox1.Text +"';", mycon);

                sqlcom.ExecuteNonQuery();
                sqlcom.Dispose();
                SqlDataAdapter adapter = new SqlDataAdapter("select uname,umon from [user] where uno='" + textBox1.Text + "'", mycon);

                // 创建DataSet，用于存储数据.
                DataSet testDataSet = new DataSet();

                // 执行查询，并将数据导入DataSet.
                adapter.Fill(testDataSet);


                DataTable tbl = testDataSet.Tables[0];

                DataRow row = tbl.Rows[0];
                label10.Text = row[0].ToString();
                label11.Text = row[1].ToString();
                MessageBox.Show("收银成功");
                mycon.Close();
            }
            else
                MessageBox.Show("余额不足");

        }

        private void button2_Click(object sender, EventArgs e)
        {

            float a = float.Parse(textBox3.Text) * float.Parse(textBox2.Text) / 100;
            SqlConnection mycon = new SqlConnection("Data Source=sql.dingjingjing.info;Database=lg;User ID=djj;PWD=sql6871592");
            mycon.Open();
            SqlDataAdapter adapter1 = new SqlDataAdapter("select uname,umon from [user] where uno='" + textBox1.Text + "'", mycon);

            // 创建DataSet，用于存储数据.
            DataSet testDataSet1 = new DataSet();

            // 执行查询，并将数据导入DataSet.
            adapter1.Fill(testDataSet1);


            DataTable tbl1 = testDataSet1.Tables[0];

            DataRow row1 = tbl1.Rows[0];
            SqlCommand sqlcom = new SqlCommand("update [user] set usco=usco+" + a.ToString() + " where uno='" + textBox1.Text + "';", mycon);

            sqlcom.ExecuteNonQuery();
            sqlcom.Dispose();
            SqlDataAdapter adapter = new SqlDataAdapter("select uname,umon from [user] where uno='" + textBox1.Text + "'", mycon);

            // 创建DataSet，用于存储数据.
            DataSet testDataSet = new DataSet();

            // 执行查询，并将数据导入DataSet.
            adapter.Fill(testDataSet);


            DataTable tbl = testDataSet.Tables[0];

            DataRow row = tbl.Rows[0];
            label10.Text = row[0].ToString();
            label11.Text = row[1].ToString();
            MessageBox.Show("积分成功");
            mycon.Close();
        }
    }
}

