﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;


namespace lanhui
{  
    public partial class zhu : Form
    {
        
        public zhu()
        {
            InitializeComponent();
        }

        private void zhu_Load(object sender, EventArgs e)
        {
          
        }

        private void zhu_FormClosed(object sender, FormClosedEventArgs e)
        {
            System.Environment.Exit(0);
        }


        

        private void button3_Click(object sender, EventArgs e)
        {
            shou shou1 = new shou();
            shou1.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            chaxun chaxun1 = new chaxun();
            chaxun1.Show();
        }
    }
}
