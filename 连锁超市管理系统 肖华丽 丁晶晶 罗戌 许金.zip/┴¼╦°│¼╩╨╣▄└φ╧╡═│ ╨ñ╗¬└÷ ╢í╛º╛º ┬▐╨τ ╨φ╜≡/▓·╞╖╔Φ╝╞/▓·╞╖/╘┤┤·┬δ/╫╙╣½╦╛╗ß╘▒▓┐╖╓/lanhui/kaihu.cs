﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace lanhui
{
    public partial class kaihu : Form
    {
        string aa = "sql.dingjingjing.info";
        public kaihu()
        {
            InitializeComponent();
        }

        private void kaihu_Load(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection mycon = new SqlConnection("Data Source=" + aa + ";Database=lg;User ID=djj;PWD=sql6871592");
            mycon.Open();
            if (textBox1.Text !=""&& textBox2.Text != "" && textBox3.Text !="")
            {
                SqlCommand sqlcom = new SqlCommand("insert into [user](uno,uname,utel,usco,umon,uid) values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "',0,0,"+"'"+textBox4.Text+"')", mycon);
                sqlcom.ExecuteNonQuery();

                sqlcom.Dispose();
                MessageBox.Show("开户成功");
            }
            else
                MessageBox.Show("请完善数据");
            mycon.Close();
            }

        private void label4_Click(object sender, EventArgs e)
        {

        }
       


        }
    }

