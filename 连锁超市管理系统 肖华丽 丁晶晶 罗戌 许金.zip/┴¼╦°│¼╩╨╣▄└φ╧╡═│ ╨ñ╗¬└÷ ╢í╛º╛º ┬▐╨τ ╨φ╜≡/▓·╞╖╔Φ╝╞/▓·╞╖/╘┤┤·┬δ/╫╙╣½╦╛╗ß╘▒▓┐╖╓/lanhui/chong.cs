﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace lanhui
{
    public partial class chong : Form
    {
        string aa = "sql.dingjingjing.info";
        public chong()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                SqlConnection mycon = new SqlConnection("Data Source=" + aa + ";Database=lg;User ID=djj;PWD=sql6871592");
                mycon.Open();
                SqlDataAdapter adapter = new SqlDataAdapter("select uname from [user] where uno='" + textBox1.Text + "'", mycon);

                // 创建DataSet，用于存储数据.
                DataSet testDataSet = new DataSet();

                // 执行查询，并将数据导入DataSet.
                adapter.Fill(testDataSet);


                DataTable tbl = testDataSet.Tables[0];

                DataRow row = tbl.Rows[0];
                label4.Text = row[0].ToString();
                mycon.Close();
            }
            catch { }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection mycon = new SqlConnection("Data Source=" + aa + ";Database=lg;User ID=djj;PWD=sql6871592");
            mycon.Open();
            if (MessageBox.Show("是否为卡号为" + textBox1.Text +"的客户 "+label4.Text+ "充值 " + textBox2.Text + "元", "确认充值", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                SqlCommand sqlcom = new SqlCommand("update [user] set umon=umon+" + textBox2.Text + " where uno='" + textBox1.Text + "';", mycon);

                sqlcom.ExecuteNonQuery();
                sqlcom.Dispose();
                SqlDataAdapter adapter = new SqlDataAdapter("select usco,umon from [user] where uno='" + textBox1.Text + "'", mycon);

                // 创建DataSet，用于存储数据.
                DataSet testDataSet = new DataSet();

                // 执行查询，并将数据导入DataSet.
                adapter.Fill(testDataSet);


                DataTable tbl = testDataSet.Tables[0];

                DataRow row = tbl.Rows[0];
                MessageBox.Show("充值完成！ 余额为"+row[1].ToString()+" 积分为"+row[0].ToString());
            }
            mycon.Close();
        }

        private void chong_Load(object sender, EventArgs e)
        {

        }
    }
}
