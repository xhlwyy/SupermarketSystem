﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace main
{
    public partial class ffind : Form
    {
        public ffind()
        {
            InitializeComponent();
        }

        private void userfind_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection mycon = new SqlConnection("Data Source=sql.dingjingjing.info;Database=lg;User ID=djj;PWD=sql6871592");
                mycon.Open();
                SqlDataAdapter adapter = new SqlDataAdapter("select cno,cpeo,cadr,ctel from comp where cname='" + textBox1.Text + "'", mycon);

                // 创建DataSet，用于存储数据.
                DataSet testDataSet = new DataSet();

                // 执行查询，并将数据导入DataSet.
                adapter.Fill(testDataSet);


                DataTable tbl = testDataSet.Tables[0];

                DataRow row = tbl.Rows[0];
                label6.Text = row[0].ToString();
                label7.Text = row[1].ToString();
                label8.Text = row[2].ToString();
                label9.Text = row[3].ToString();
                MessageBox.Show("查询成功");
                mycon.Close();
            }
            catch {
                MessageBox.Show("输入的名称不正确，请重新输入");
            }

        }
    }
}
