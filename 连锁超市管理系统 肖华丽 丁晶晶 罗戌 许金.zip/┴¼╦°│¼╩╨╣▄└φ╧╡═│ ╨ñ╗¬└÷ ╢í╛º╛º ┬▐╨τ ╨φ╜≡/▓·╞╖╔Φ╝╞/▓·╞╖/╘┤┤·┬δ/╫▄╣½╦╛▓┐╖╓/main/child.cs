﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace main
{
    public partial class child : Form
    {
        public child()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection mycon = new SqlConnection("Data Source=sql.dingjingjing.info;Database=lg;User ID=djj;PWD=sql6871592");
            mycon.Open();

            SqlCommand sqlcom = new SqlCommand("insert into comp(cno,cpeo,cname,cadr,ctel) values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "')", mycon);
            sqlcom.ExecuteNonQuery();

            sqlcom.Dispose();
            MessageBox.Show("公司" + textBox3.Text + "开户成功，代码为" + textBox1.Text);
            mycon.Close();
        }

        private void child_Load(object sender, EventArgs e)
        {

        }
    }
}
