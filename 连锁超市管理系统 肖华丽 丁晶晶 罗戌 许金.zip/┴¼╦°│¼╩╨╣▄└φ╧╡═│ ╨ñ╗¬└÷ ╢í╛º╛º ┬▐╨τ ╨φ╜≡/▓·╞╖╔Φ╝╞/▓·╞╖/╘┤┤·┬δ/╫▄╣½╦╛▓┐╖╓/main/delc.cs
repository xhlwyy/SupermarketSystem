﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace main
{
    public partial class delc : Form
    {
        public delc()
        {
            InitializeComponent();
        }

        private void delc_Load(object sender, EventArgs e)
        {

            SqlConnection mycon = new SqlConnection("Data Source=sql.dingjingjing.info;Database=lg;User ID=djj;PWD=sql6871592");
            mycon.Open();
            SqlDataAdapter adapter = new SqlDataAdapter("select cname from comp ", mycon);

            // 创建DataSet，用于存储数据.
            DataSet testDataSet = new DataSet();

            // 执行查询，并将数据导入DataSet.
            adapter.Fill(testDataSet);

            int i;
            DataTable tbl = testDataSet.Tables[0];
            for (i = tbl.Rows.Count; i > 0; i--)
            {
                comboBox1.Items.Add(tbl.Rows[i - 1][0].ToString());
            }
            mycon.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection mycon = new SqlConnection("Data Source=sql.dingjingjing.info;Database=lg;User ID=djj;PWD=sql6871592");
                mycon.Open();
                string s = comboBox1.SelectedItem.ToString();



                SqlCommand sqlcom = new SqlCommand("delete from comp WHERE cname='" + s + "'", mycon);
                sqlcom.ExecuteNonQuery();
                sqlcom.Dispose();
                MessageBox.Show("销户成功");
                this.Close();
                mycon.Close();
            }
            catch { MessageBox.Show("请选择公司名称"); }
        }
    }
}
