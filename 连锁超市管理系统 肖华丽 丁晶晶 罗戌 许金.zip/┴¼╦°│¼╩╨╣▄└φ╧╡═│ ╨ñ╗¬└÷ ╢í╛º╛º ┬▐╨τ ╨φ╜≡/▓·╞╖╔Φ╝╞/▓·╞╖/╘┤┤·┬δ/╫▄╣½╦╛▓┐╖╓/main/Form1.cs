﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace main
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        public  void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection mycon = new SqlConnection("Data Source=sql.dingjingjing.info;Database=lg;User ID=djj;PWD=sql6871592");
                mycon.Open();
                MessageBox.Show("远程数据库连接成功");
                mycon.Close();
            }
            catch
            { MessageBox.Show("远程数据库连接超时，请检查网络连接");
            this.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection mycon = new SqlConnection("Data Source=sql.dingjingjing.info;Database=lg;User ID=djj;PWD=sql6871592");
            mycon.Open();

            try
            {
                SqlDataAdapter adapter = new SqlDataAdapter("select aname,apwd from admin where aname='" + textBox1.Text + "'", mycon);

                // 创建DataSet，用于存储数据.
                DataSet testDataSet = new DataSet();

                // 执行查询，并将数据导入DataSet.
                adapter.Fill(testDataSet);


                DataTable tbl = testDataSet.Tables[0];

                DataRow row = tbl.Rows[0];
                
                if (row[1].ToString() == textBox2.Text)
                {
                    zhu zhu1;
                    zhu1 = new zhu();
                    zhu1.Show();
                    this.Hide();
                    MessageBox.Show(row[0].ToString()+"登录成功");

                }

                else
                {
                    MessageBox.Show("账户名或密码错误，请重新输入");
                    textBox1.Text = "";
                    textBox2.Text = "";
                }
            }
            catch
            {
                MessageBox.Show("账户名或密码错误，请重新输入");
                textBox1.Text = "";
                textBox2.Text = "";
            }
            mycon.Close();

        }
    }
}
