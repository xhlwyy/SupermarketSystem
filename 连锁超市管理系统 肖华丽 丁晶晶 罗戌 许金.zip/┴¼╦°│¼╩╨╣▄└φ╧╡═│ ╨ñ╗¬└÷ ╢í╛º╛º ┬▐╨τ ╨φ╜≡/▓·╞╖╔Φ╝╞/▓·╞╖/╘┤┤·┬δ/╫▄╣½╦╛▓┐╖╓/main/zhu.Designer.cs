﻿namespace main
{
    partial class zhu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.公司管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.公司查询ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.公司销户ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.菜单ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.子公司开户ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.子公司主管理员开户ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.安全退出ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.公司管理ToolStripMenuItem,
            this.菜单ToolStripMenuItem,
            this.安全退出ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(364, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 公司管理ToolStripMenuItem
            // 
            this.公司管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.公司查询ToolStripMenuItem,
            this.公司销户ToolStripMenuItem});
            this.公司管理ToolStripMenuItem.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.公司管理ToolStripMenuItem.Name = "公司管理ToolStripMenuItem";
            this.公司管理ToolStripMenuItem.Size = new System.Drawing.Size(85, 24);
            this.公司管理ToolStripMenuItem.Text = "公司管理";
            // 
            // 公司查询ToolStripMenuItem
            // 
            this.公司查询ToolStripMenuItem.Name = "公司查询ToolStripMenuItem";
            this.公司查询ToolStripMenuItem.Size = new System.Drawing.Size(152, 24);
            this.公司查询ToolStripMenuItem.Text = "公司查询";
            this.公司查询ToolStripMenuItem.Click += new System.EventHandler(this.公司查询ToolStripMenuItem_Click);
            // 
            // 公司销户ToolStripMenuItem
            // 
            this.公司销户ToolStripMenuItem.Name = "公司销户ToolStripMenuItem";
            this.公司销户ToolStripMenuItem.Size = new System.Drawing.Size(152, 24);
            this.公司销户ToolStripMenuItem.Text = "公司销户";
            this.公司销户ToolStripMenuItem.Click += new System.EventHandler(this.公司销户ToolStripMenuItem_Click);
            // 
            // 菜单ToolStripMenuItem
            // 
            this.菜单ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.子公司开户ToolStripMenuItem,
            this.子公司主管理员开户ToolStripMenuItem});
            this.菜单ToolStripMenuItem.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.菜单ToolStripMenuItem.Name = "菜单ToolStripMenuItem";
            this.菜单ToolStripMenuItem.Size = new System.Drawing.Size(85, 24);
            this.菜单ToolStripMenuItem.Text = "开户管理";
            this.菜单ToolStripMenuItem.Click += new System.EventHandler(this.菜单ToolStripMenuItem_Click);
            // 
            // 子公司开户ToolStripMenuItem
            // 
            this.子公司开户ToolStripMenuItem.Name = "子公司开户ToolStripMenuItem";
            this.子公司开户ToolStripMenuItem.Size = new System.Drawing.Size(222, 24);
            this.子公司开户ToolStripMenuItem.Text = "子公司开户";
            this.子公司开户ToolStripMenuItem.Click += new System.EventHandler(this.子公司开户ToolStripMenuItem_Click);
            // 
            // 子公司主管理员开户ToolStripMenuItem
            // 
            this.子公司主管理员开户ToolStripMenuItem.Name = "子公司主管理员开户ToolStripMenuItem";
            this.子公司主管理员开户ToolStripMenuItem.Size = new System.Drawing.Size(222, 24);
            this.子公司主管理员开户ToolStripMenuItem.Text = "子公司主管理员开户";
            this.子公司主管理员开户ToolStripMenuItem.Click += new System.EventHandler(this.子公司主管理员开户ToolStripMenuItem_Click);
            // 
            // 安全退出ToolStripMenuItem
            // 
            this.安全退出ToolStripMenuItem.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F);
            this.安全退出ToolStripMenuItem.Name = "安全退出ToolStripMenuItem";
            this.安全退出ToolStripMenuItem.Size = new System.Drawing.Size(85, 24);
            this.安全退出ToolStripMenuItem.Text = "安全退出";
            this.安全退出ToolStripMenuItem.Click += new System.EventHandler(this.安全退出ToolStripMenuItem_Click);
            // 
            // zhu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(364, 137);
            this.Controls.Add(this.menuStrip1);
            this.Location = new System.Drawing.Point(650, 345);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "zhu";
            this.Text = "乐购子公司管理系统";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.zhu_FormClosing);
            this.Load += new System.EventHandler(this.zhu_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 菜单ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 子公司开户ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 公司管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 子公司主管理员开户ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 公司查询ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 公司销户ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 安全退出ToolStripMenuItem;
    }
}