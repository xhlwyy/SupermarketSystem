﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace main
{
    public partial class zhu : Form
    {
        public zhu()
        {
            InitializeComponent();
        }

        private void zhu_Load(object sender, EventArgs e)
        {

        }

        private void zhu_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Environment.Exit(0);
        }

        private void 菜单ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 公司名ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 公司编号ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 安全退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }

        private void 子公司开户ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            child child1 = new child();
            child1.Show();
        }

        private void 子公司主管理员开户ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            childa childa1 = new childa();
            childa1.Show();
        }

        private void 公司查询ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ffind ffind1 = new ffind();
            ffind1.Show();
        }

        private void 公司销户ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            delc delc1 = new delc();
            delc1.Show();
        }
    }
}
