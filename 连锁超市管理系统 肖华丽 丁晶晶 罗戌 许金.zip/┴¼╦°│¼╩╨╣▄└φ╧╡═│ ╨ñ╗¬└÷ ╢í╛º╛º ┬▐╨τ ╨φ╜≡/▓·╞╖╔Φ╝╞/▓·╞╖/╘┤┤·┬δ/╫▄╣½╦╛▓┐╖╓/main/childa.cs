﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace main
{
    public partial class childa : Form
    {
        public childa()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            SqlConnection mycon = new SqlConnection("Data Source=sql.dingjingjing.info;Database=lg;User ID=djj;PWD=sql6871592");
            mycon.Open();
            string s = comboBox1.SelectedItem.ToString();
           
            SqlDataAdapter adapter = new SqlDataAdapter("select cno from comp where cname='"+s+"'", mycon);
            DataSet testDataSet = new DataSet();

            // 执行查询，并将数据导入DataSet.
            adapter.Fill(testDataSet);
            DataTable tb1 = testDataSet.Tables[0];

            SqlCommand sqlcom = new SqlCommand("insert into admin(aname,apwd,akind,cno,ao) values('"+ textBox2.Text + "','" + textBox3.Text + "','" + "cadmin" + "','" +tb1.Rows[0][0].ToString()+"','"+ textBox5.Text + "')", mycon);
            sqlcom.ExecuteNonQuery();

            sqlcom.Dispose();
            MessageBox.Show("开户成功");
            this.Close();
            mycon.Close();
            
        }

        private void childa_Load(object sender, EventArgs e)
        {
            SqlConnection mycon = new SqlConnection("Data Source=sql.dingjingjing.info;Database=lg;User ID=djj;PWD=sql6871592");
            mycon.Open();
            SqlDataAdapter adapter = new SqlDataAdapter("select cname from comp ", mycon);

            // 创建DataSet，用于存储数据.
            DataSet testDataSet = new DataSet();

            // 执行查询，并将数据导入DataSet.
            adapter.Fill(testDataSet);

            int i;
            DataTable tbl = testDataSet.Tables[0];
            for (i = tbl.Rows.Count; i>0; i--)
            { comboBox1.Items.Add(tbl.Rows[i-1][0].ToString());
            }
            mycon.Close();
        }
    }
}
